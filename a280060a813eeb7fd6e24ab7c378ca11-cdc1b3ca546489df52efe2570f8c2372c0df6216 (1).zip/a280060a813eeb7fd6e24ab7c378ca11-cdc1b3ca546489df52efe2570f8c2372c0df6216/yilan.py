import random
import time

def oyun_baslat():
    print("====================================")
    print("      🌌 KAYIP GEZEGEN: OMNIS 🌌    ")
    print("====================================\n")
    print("Yıl 2026. Keşif geminiz mor bulutlu yabancı bir gezegene acil iniş yaptı.")
    print("Geminhasarlı ve enerjiniz az. Telsizden gizemli bir sinyal geliyor.\n")
    
    cantadaki_esya = "Fener"
    print(f"🎒 Çantanızdaki mevcut eşya: {cantadaki_esya}\n")
    
    # Birinci Seçim
    print("Önünüzde üç yol var:")
    print("1 - Yeraltından sesler gelen metal antik tesise gir.")
    print("2 - Parlayan mor kristal mağaraya doğru yürü.")
    print("3 - Gemide kal ve telsiz sinyalini çözmeye çalış.")
    
    secim1 = input("\nSeçiminiz (1, 2 veya 3): ")
    
    if secim1 == "1":
        tesis_yolu(cantadaki_esya)
    elif secim1 == "2":
        magara_yolu(cantadaki_esya)
    elif secim1 == "3":
        gemi_yolu()
    else:
        print("\n❌ Geçersiz bir sayı girdiniz ve panikleyerek gemide beklediniz. Enerji bitti!")
        oyun_bitti(False)

def tesis_yolu(esya):
    print("\n------------------------------------")
    print("🏛️ ANTIK TESIS YOLU")
    print("------------------------------------")
    print("Devasa metal kapılardan içeri girdiniz. İçerisi çok karanlık.")
    time.sleep(1)
    
    print(f"Çantanızdaki {esya} yardımıyla önünüzü aydınlattınız.")
    print("Karşınıza aniden eski bir savunma robotu çıktı! Gözleri kırmızı yanıyor.")
    
    secim = input("\nNe yapacaksınız? (1: Savaş / 2: Kaç): ")
    
    if secim == "1":
        # Şans faktörü %50
        sans = random.choice([True, False])
        if sans:
            print("\n🤖 Robotun kablolarını koparmayı başardınız! Tesisin kontrol odasına ulaştınız.")
            print("🚀 Buradaki ana bilgisayarı kullanarak geminizi tamir ettiniz ve kurtuldunuz!")
            oyun_bitti(True)
        else:
            print("\n🤖 Robot sizi fark etti ve lazer silahıyla etkisiz hale getirdi.")
            oyun_bitti(False)
    else:
        print("\n🏃 Koşarak kaçmaya çalışırken karanlıkta bir çukura düştünüz.")
        oyun_bitti(False)

def magara_yolu(esya):
    print("\n------------------------------------")
    print("🔮 KRISTAL MAĞARA YOLU")
    print("------------------------------------")
    print("Mağaranın içi mor kristallerle parlıyor. Hava çok sıcak.")
    time.sleep(1)
    
    print("Yerde parıldayan kadim bir uzaylı madalyonu buldunuz.")
    secim = input("\nMadalyonu alacak mısınız? (1: Evet / 2: Hayır): ")
    
    if secim == "1":
        print("\n🏅 Madalyonu aldığınız anda mağara çökmeye başladı!")
        print("💨 Son güçle kendinizi dışarı attınız ve madalyonun içindeki enerjiyle gemiyi çalıştırdınız!")
        oyun_bitti(True)
    else:
        print("\nMağarada yürümeye devam ettiniz ama zehirli gazlardan dolayı bayıldınız.")
        oyun_bitti(False)

def gemi_yolu():
    print("\n------------------------------------")
    print("🚀 GEMI KONTROL PANELİ")
    print("------------------------------------")
    print("Gemide kalıp bilgisayar başında sinyali çözmeye odaklandınız.")
    time.sleep(1)
    
    print("Sinyal bir şifre içeriyor. Şifre 1 ile 5 arasında gizli bir sayı!")
    gizli_sayi = random.randint(1, 5)
    
    tahmin = int(input("\nTelsiz şifresi tahmininiz (1-5 arası): "))
    
    if tahmin == gizli_sayi:
        print(f"\n📡 Doğru şifre ({gizli_sayi})! Sinyal yakındaki bir kurtarma gemisine ait çıktı.")
        print("🛸 Kurtarma ekibi yerinizi tespit etti ve sizi kurtardı!")
        oyun_bitti(True)
    else:
        print(f"\n❌ Yanlış şifre! Doğru şifre {gizli_sayi} olmalıydı. Zaman kaybettiniz ve oksijen bitti.")
        oyun_bitti(False)

def oyun_bitti(kazandi_mi):
    print("\n====================================")
    if kazandi_mi:
        print("🎉 TEBRİKLER! GEZEGENDEN KURTULDUNUZ VE OYUNU KAZANDINIZ! 🎉")
    else:
        print("💀 OYUN BİTTİ! Gezegende mahsur kaldınız... 💀")
    print("====================================\n")
    
    tekrar = input("Tekrar oynamak ister misiniz? (e/h): ")
    if tekrar.lower() == 'e':
        oyun_baslat()
    else:
        print("Oynadığınız için teşekkürler!")

# Oyunu çalıştır
oyun_baslat()

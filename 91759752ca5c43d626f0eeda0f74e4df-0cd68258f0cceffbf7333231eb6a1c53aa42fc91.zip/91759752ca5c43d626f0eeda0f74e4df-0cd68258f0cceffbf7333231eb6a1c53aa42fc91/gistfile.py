@echo off  
Start(;1 2 3 ,).virüs bulaşsın